This application removes the System32 folder!

Check in a virtual machine!





                                               Be sure to unpack!
